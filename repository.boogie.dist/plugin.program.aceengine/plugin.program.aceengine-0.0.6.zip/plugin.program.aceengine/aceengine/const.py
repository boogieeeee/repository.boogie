'''
Created on Oct 6, 2022

@author: boogie
'''

ADDONID = "plugin.program.aceengine"
BINARY = "acestreamengine"
SETTING_ISREMOTE = "ace_isremote"
SETTING_ADDRESS = "ace_remoteip"
SETTING_PORT = "ace_port"
SETTING_MAXCONS = "ace_max_connections"
SETTING_MAXPEERS = "ace_max_peers"
SETTING_MAXUP = "ace_max_upload_speed"
SETTING_MAXDOWN = "ace_max_download_speed"
SETTING_USECWD = "ace_usecwd"
SETTING_CWD = "ace_cwd"
SETTING_ISRUNNING = "ace_isrunning"
SETTING_ACTIVEADDRESS = "ace_address"
RETRY = 3
MAXLINES = 20
CLOSETIMEOUT = 10
STREAMHAY = "streams"
STREAMHAY_KEY = "live"
