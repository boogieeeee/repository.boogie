'''
Created on Nov 21, 2019

@author: boogie
'''
from tinyxbmc import stubmod
from vods import linkplayerextension
from tinyxbmc import extension
from tinyxbmc import tools
from tinyxbmc import const
from tinyxbmc import mediaurl
import re
import os

ppath = os.path.join(os.path.dirname(__file__), "libstreams")


class Test:
    link = None
    headers = {}

    def test_link(self):
        if not self.link:
            return
        s = streams(None)
        found = False
        for link in s.geturls(self.link, self.headers):
            self.assertIsInstance(link, mediaurl.BaseUrl)
            found = True
        self.assertTrue(found)


class StreamsBase:
    regex = None
    testlink = None

    def resolve(self, url, headers):
        return mediaurl.LinkUrl(url, headers)


class streams(linkplayerextension):
    title = "Streams Link Extension"
    dropboxtoken = const.DB_TOKEN

    def init(self):
        self.providers = [x[1] for x in extension.getobjects(ppath, parents=[StreamsBase])]

    def geturls(self, url, headers=None):
        for provider in self.providers:
            if provider.regex and re.search(provider.regex, url):
                for linkurl in tools.safeiter(provider().resolve(url, headers)):
                    yield linkurl
                break
