'''
Created on Jun 5, 2022

@author: boogie
'''
chnames = {1: "Premier Sports 1 (UK)",
           3: "SK 3 (CR)",
           5: "M+ (ES)",
           6: "Bein Sports 3 (AR)",
           8: "Super Sport PL (UK)",
           10: "Sport TV 3 (PT)",
           11: "Premier Sports 1 (UK)",
           13: "Super Sport Football (UK)",
           14: "Premier Sports 1 (UK)",
           15: "Sport TV 3 (PT)",
           16: "M+ LaLiga (ES)",
           17: "Bein Sports 2 (AR)",
           18: "BT Sport 2 (UK)",
           19: "SK 2 (CR)",
           23: "Sky Sports F1 (UK)"}