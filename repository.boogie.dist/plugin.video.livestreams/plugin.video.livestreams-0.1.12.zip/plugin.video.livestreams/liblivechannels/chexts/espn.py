# -*- encoding: utf-8 -*-
try:
    import unittest
    from test import ChannelTest

    class testespn(ChannelTest, unittest.TestCase):
        index = "espn:espn:"
        minepg = 0

    class testespn2(ChannelTest, unittest.TestCase):
        index = "espn:espn2:"
        minepg = 0

except ImportError:
    pass


from liblivechannels.chexts.scrapertools.sports24 import sports24chan
from liblivechannels.chexts.scrapertools.yoursports import yoursports
from liblivechannels import scraper
from liblivechannels.chexts.scrapertools import vercel


class espn(sports24chan, scraper):
    icon = "https://logosmarken.com/wp-content/uploads/2020/12/ESPN-Logo-650x366.png"
    chid = "espn"
    title = "ESPN"

    def iterprogrammes(self):
        for p in vercel.iterprogrammes("10179"):
            yield p


class espn2(yoursports, scraper):
    icon = "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bf/ESPN2_logo.svg/800px-ESPN2_logo.svg.png"
    chid = "espn2"
    title = "ESPN 2"

    def iterprogrammes(self):
        for p in vercel.iterprogrammes("12444"):
            yield p
 