'''
Created on Aug 2, 2021

@author: boogie
'''
from tinyxbmc import net
import htmlement
import re


dom = "canlitv.center"
domain = "https://" + dom
url = domain + "/yayin/"


def itermedias(ctvcid):
    u = url + ctvcid
    for script in htmlement.fromstring(net.http(u, referer=domain)).findall(".//script"):
        scripturl = script.get("src")
        if scripturl is not None and dom in scripturl:
            iframepage = net.http(script.get("src"), referer=u)
            for var in re.findall("yayincomtr[0-9]+[\s\t]*?=[\s\t]*?(?:\'|\")((?:https|http|\/\/).+?)(?:\'|\")", iframepage):
                if ".m3u8" in var:
                    yield net.hlsurl(net.absurl(var, domain), headers={"referer": domain})
