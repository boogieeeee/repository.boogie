'''
Created on Feb 22, 2020

@author: boogie
'''
import os

hay_chan = "channels"
addon_id = "plugin.video.livestreams"
query_timeout = 2
playlist_timeout = 10
dpath = os.path.join(os.path.dirname(__file__), "scrapers")
