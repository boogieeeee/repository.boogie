# -*- encoding: utf-8 -*-
from liblivechannels.chexts.scrapertools import youtube
from liblivechannels.chexts.scrapertools import canlitvcenter
from liblivechannels.chexts.scrapertools import canlitvme

from liblivechannels.chexts.scrapertools import yayinakisi
from liblivechannels.chexts.scrapertools import vercel
from liblivechannels.chexts.scrapertools import mynetyayin

from tinyxbmc.tools import safeiter
from tinyxbmc import mediaurl


class multi:
    directs = []

    # acestreams
    acestreams = []

    # youtube
    youtube_chanid = None
    youtube_sindex = 0

    # canlitvme
    canlitvme_name = None

    # canlitvcenter
    canlitvcenter_name = None

    # sports24
    sports24_id = None

    # epg: yayinakisi
    yayin_name = None
    yayin_id = None

    # epg: vercel
    vercel_id = None

    # epg: mynet
    mynet_yayin = None

    def get(self):
        if self.youtube_chanid:
            for yayin in safeiter(youtube.itermedias(self.youtube_chanid, self.youtube_sindex)):
                yield yayin
        for acestream in self.acestreams:
            yield mediaurl.AceUrl(acestream)
        for direct in self.directs:
            yield direct
        if self.canlitvme_name:
            for yayin in safeiter(canlitvme.itermedias(self.canlitvme_name)):
                yield yayin
        if self.canlitvcenter_name:
            for yayin in safeiter(canlitvcenter.itermedias(self.canlitvcenter_name)):
                yield yayin

    def iterprogrammes(self):
        if self.yayin_id or self.yayin_name:
            for prog in yayinakisi.iterprogrammes(self.yayin_name, self.yayin_id):
                yield prog
        if self.vercel_id:
            for prog in vercel.iterprogrammes(self.vercel_id):
                yield prog
        if self.mynet_yayin:
            for prog in mynetyayin.iterprogrammes(self.mynet_yayin):
                yield prog
