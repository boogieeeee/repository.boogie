import time
import json

from six.moves.urllib import parse
from six.moves import queue

from liblivechannels import common
from thirdparty.m3u8 import model

from tinyxbmc import addon
from tinyxbmc import net


class PlaylistGenerator(object):
    def __init__(self, base):
        self.base = base
        self.playlists = queue.Queue()
        self.index = 10

    @staticmethod
    def sorter(playlist):
        return playlist.stream_info.bandwidth

    def add(self, m3file, headers, useproxy):
        if len(m3file.playlists):
            for playlist in sorted(m3file.playlists, key=self.sorter, reverse=True):
                if useproxy:
                    self.headcheck(playlist, headers, useproxy)
                    if self.playlists.qsize():
                        break
                else:
                    playlist.uri = net.tokodiurl(playlist.absolute_uri, headers=headers)
                    self.playlists.put(playlist)
        elif len(m3file.segments):
            if not useproxy:
                m3file.full_uri = net.tokodiurl(m3file.full_uri, headers=headers)
            else:
                m3file.full_uri = encodeurl(url=m3file.full_uri, headers=headers)
            self.index += 1
            playlist = model.Playlist(m3file.full_uri,
                                      {"bandwidth": self.index},
                                      None, m3file.base_uri)
            self.playlists.put(playlist)

    def headcheck(self, playlist, headers, useproxy):
        error = self.base.healthcheck(playlist.absolute_uri, headers)
        if error is None:
            if not useproxy:
                playlist.uri = net.tokodiurl(playlist.absolute_uri, headers=headers)
            else:
                playlist.uri = encodeurl(url=playlist.absolute_uri, headers=headers)
            self.playlists.put(playlist)

    @property
    def m3file(self):
        m3file = model.M3U8()
        while True:
            try:
                m3file.add_playlist(self.playlists.get(False))
            except queue.Empty:
                break
        return m3file


def decodeurl(path):
    query = parse.urlparse(path)
    kwargs = dict(parse.parse_qsl(query.query))
    for kwarg in kwargs:
        kwargs[kwarg] = json.loads(parse.unquote_plus(kwargs[kwarg]))
    return kwargs


def encodeurl(**kwargs):
    port = addon.kodisetting(common.addon_id).getstr("port")
    for kwarg in kwargs:
        kwargs[kwarg] = parse.quote_plus(json.dumps(kwargs[kwarg]))
    return "http://localhost:%s/?%s" % (port, parse.urlencode(kwargs))
