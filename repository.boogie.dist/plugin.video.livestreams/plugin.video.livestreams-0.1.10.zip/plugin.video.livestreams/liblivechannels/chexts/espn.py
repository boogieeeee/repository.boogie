# -*- encoding: utf-8 -*-
try:
    import unittest
    from test import ChannelTest

    class testespn(ChannelTest, unittest.TestCase):
        index = "espn:espn:"
        minepg = 0

except ImportError:
    pass


from liblivechannels.chexts.scrapertools.sports24 import sports24chan
from liblivechannels import scraper
from liblivechannels.chexts.scrapertools import vercel


class espn(sports24chan, scraper):
    icon = "https://logosmarken.com/wp-content/uploads/2020/12/ESPN-Logo-650x366.png"
    chid = "espn"
    title = "ESPN"

    def iterprogrammes(self):
        for p in vercel.iterprogrammes("10179"):
            yield p
