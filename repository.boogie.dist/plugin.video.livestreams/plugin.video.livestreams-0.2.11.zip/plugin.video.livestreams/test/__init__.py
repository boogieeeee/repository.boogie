import unittest
import sys
import os
sys.argv[0] = "plugin://plugin.video.livestreams"

from tinyxbmc import stubmod
from tinyxbmc import net
from tinyxbmc import tools
from tinyxbmc import const
import addon

if not stubmod.isstub():
    raise ImportError

stubmod.rootpath = os.path.realpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))

base = addon.Base()


def testlink(unit, it, minlinks, title, index):
    valids = []
    invalids = []
    for link in tools.safeiter(it):
        error, _resp, _headers = base.healthcheck(link)
        if error is not None:
            invalids.append((error, link))
        else:
            valids.append(link)
    unit.assertFalse(minlinks > len(valids), "%s, %s, Minimum requried link is %s but available is %s."
                                             "Invalids:%s"
                                             "Valids:%s" % (title,
                                                            index,
                                                            minlinks,
                                                            len(valids),
                                                            invalids,
                                                            valids))


class ChannelTest():
    minlinks = 1
    minepg = 1
    thumbnail = True

    def setUp(self):
        for channel in base.iterchannels():
            if channel.index == self.index:
                self.channel = channel(net.http)
                break

    def test_links(self):
        error = None
        if self.channel.checkerrors is not None:
            error = self.channel.checkerrors()
        if error is None:
            testlink(self, self.channel.get(), self.minlinks, self.channel.title, self.channel.index)

    def test_thumbnail(self):
        if self.thumbnail:
            self.assertFalse(self.channel.icon is None)
            self.assertFalse(self.channel.icon == const.DEFAULT_FOLDER)
            if self.channel.icon.startswith("http"):
                resp = net.http(self.channel.icon, method="HEAD")
                self.assertFalse(resp is None)
                self.assertTrue(resp.status_code >= 200 and resp.status_code < 300)

    def test_epg(self):
        if self.minepg:
            self.assertTrue(len(list(self.channel.iterprogrammes())) >= self.minepg)
