'''
Created on Jul 16, 2021

@author: boogie
'''
# -*- encoding: utf-8 -*-
import ghub
import re
import sys
import os
from tinyxbmc import addon

# sys.argv = [1, 1]

ardundzdf = ghub.load("rols1", "Kodi-Addon-ARDundZDF", "master", path=["resources", "lib"])
ghub.load("romanvm", "kodi.six", "master", path=["script.module.kodi-six","libs"])

utilfile = os.path.join(ardundzdf, "resources", "lib", "util.py")
with open(utilfile) as f:
    utilcont = re.sub("plugin\.video\.ardundzdf", "plugin.video.livestreams", f.read())
    utilcont = re.sub("xbmcaddon.Addon\(id=ADDON_ID\)", "xbmcaddon.Addon(ADDON_ID)", utilcont)
    utilcont = re.sub("ADDON_PATH[\s\t]*?=[\s\t]*?SETTINGS.getAddonInfo.+?\n", "ADDON_PATH = '%s'\n" % ardundzdf, utilcont)
    utilcont = re.sub("USERDATA[\s\t]*?=[\s\t]*?xbmc.translatePath.+?\n", "USERDATA = '%s'\n" % os.path.join(addon.get_addondir("plugin.vdeo.livestreams"), ""), utilcont)
    utilcont = re.sub("HANDLE[\s\t]*?=[\s\t]*?int.+?\n", "HANDLE = 1", utilcont)
with open(utilfile, "w") as f:
    f.write(utilcont)


import util
util.check_DataStores()


class multi():
    categories = ["Deutschland"]
    title = u"Das Erste"
    iconpath = os.path.join(ardundzdf, "resources", "images", "")
    usehlsproxy = False
    sender = "Das Erste"

    def get(self):
        img, link, _epg = util.get_playlist_img(self.sender)
        self.icon = img
        if "ZDF" in self.sender:
            links = util.get_ZDFstreamlinks()
        elif link.startswith("http://") or link.startswith("https://"):
            yield link
        elif "ARD" in link:
            links = util.get_ARDstreamlinks()
        elif "ZDF" in link:
            links = util.get_ZDFstreamlinks()
        else:
            raise StopIteration
        for link in links:
            sender, url, img, _ = link.split("|")
            if sender == self.sender:
                yield url
                break

    def iterprogrammes(self):
        yield
