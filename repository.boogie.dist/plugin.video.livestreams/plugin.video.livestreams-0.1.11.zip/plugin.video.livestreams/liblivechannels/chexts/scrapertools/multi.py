# -*- encoding: utf-8 -*-
from liblivechannels.chexts.scrapertools.yayinakisi import yayinakisi
from liblivechannels.chexts.scrapertools.youtube import youtube
from liblivechannels.chexts.scrapertools import selcuk
from liblivechannels.chexts.scrapertools import ses
from liblivechannels.chexts.scrapertools import kolaytv

from tinyxbmc.tools import safeiter


class multi(yayinakisi, youtube):
    # kolay tv
    kolay_id = None
    kolay_ids = None
    # selcuk sports
    selcuk_name = None
    # youtube
    youtube_chanid = None
    youtube_stream = None
    youtube_sindex = None
    # ses tv
    ses_id = None
    ses_ids = None
    ses_adaptive = True
    selcuk_adaptive = True

    def get(self):
        if self.youtube_chanid:
            for yayin in safeiter(self.iteryoutube()):
                yield yayin
        if self.kolay_id or self.kolay_ids:
            for yayin in safeiter(kolaytv.itermedias(self.kolay_id, self.kolay_ids)):
                yield yayin
        if self.ses_id or self.ses_ids:
            for yayin in safeiter(ses.itermedias(self.ses_id, self.ses_ids, self.ses_adaptive)):
                yield yayin
        if self.selcuk_name:
            for yayin in safeiter(selcuk.itermedias(self.selcuk_name, self.selcuk_adaptive)):
                yield yayin
