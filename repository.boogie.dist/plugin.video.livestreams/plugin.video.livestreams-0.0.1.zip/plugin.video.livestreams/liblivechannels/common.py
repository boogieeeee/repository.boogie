'''
Created on Feb 22, 2020

@author: boogie
'''

hay_chan = "channels"
addon_id = "plugin.video.livestreams"
